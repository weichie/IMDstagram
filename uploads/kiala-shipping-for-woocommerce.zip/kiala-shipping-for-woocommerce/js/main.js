jQuery(document).ready(function(){
	
	jQuery('.woocommerce-checkout').sisyphus();
	
});
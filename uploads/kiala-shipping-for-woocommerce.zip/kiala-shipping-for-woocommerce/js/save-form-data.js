function selectKiala(dspid, country, kpid, css){
	var shortkpid;

	// Receivce kiala parameters
	var terms = kpid.split('?');
	terms = terms[1];

	// Find kpid
	var store = terms.split('&');
	console.log(store);
	for(var i=0;i<store.length;i++){
		console.log(store[i].indexOf('shortID'));
		if(store[i].indexOf('shortID') >= 0){
			// Bingo
			var skpid = store[i].split('=');
			shortkpid = skpid[1];
		}

		if(store[i].indexOf('bckUrl') >= 0){
			// Shop info
		}
	}

	// Update postfield
	jQuery('input[name="kiala_shortkpid"]').val(shortkpid);
	// Update map
	jQuery('.kiala_point_chosen').show();
	jQuery('.kiala_point_chosen_frame').html('<iframe scrolling="no" class="kiala_framed" src="http://locateandselect.kiala.com/locateandselect/details?dspid='+dspid+'&country='+country+'&language=&preparationdelay=&shortID='+shortkpid+'&map=off&css='+css+'&list=" width="100%" height="400"></iframe>');

	jQuery('.kiala_point').hide();
	jQuery('.kiala_lightbox').hide();
}
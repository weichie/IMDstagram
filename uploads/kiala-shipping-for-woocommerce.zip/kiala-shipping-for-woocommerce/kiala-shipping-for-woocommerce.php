<?php
/**
 * Plugin Name: Kiala Shipping for WooCommerce
 * Plugin URI: http://yame.be/kiala-woocommerce
 * Description: Kiala Shipping
 * Version: 1.0
 * Author: Yannick Van Meerbeeck
 * Author URI: http://yame.be/
 * License: GPL
 */

defined('ABSPATH') or die("No direct access!");

/**
 * Check if WooCommerce is active
 **/
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	/* Languages */
	load_plugin_textdomain('kiala-shipping-for-woocommerce', false, basename( dirname( __FILE__ ) ) . '/languages/' );

	// Add save checkout form js
	function pfw_save_checkout_js(){
		wp_enqueue_script('pfw-save-checkout', plugins_url('js/save-form-data.js', __FILE__), array('jquery'), '1.0.0', true);
		wp_enqueue_style('pfw-css', plugins_url('css/kiala-for-woocommerce.css', __FILE__));
		wp_enqueue_script('pfw-save-forms', plugins_url('js/sisyphus.js', __FILE__), array('jquery'), '1.0.0', true);
		wp_enqueue_script('pfw-main-js', plugins_url('js/main.js', __FILE__), array('jquery'), '1.0.0', true);
	}
	add_action('wp_enqueue_scripts', 'pfw_save_checkout_js');

    // Kiala Shipping for WooCommerce
    function kiala_shipping_init() {

		if ( ! class_exists( 'Kiala_shipping' ) ) {
			class Kiala_shipping extends WC_Shipping_Method {
				/**
				 * Constructor for your shipping class
				 *
				 * @access public
				 * @return void
				 */
				 
				 
				 public $inline;
				 public $free_shipping;
				 public $showmap;
				 public $fs_be;
				 public $fs_nl;
				 public $fs_lu;
				 public $fs_fr;
				 public $fs_es;
				 
				public $dspid;
				 
				public function __construct() {
					$this->id                 	= 'kiala';
					$this->title       			= __('Kiala Shipping', 'kiala-shipping-for-woocommerce');
					$this->method_title 		= __('Kiala', 'kiala-shipping-for-woocommerce');
					$this->method_description 	= __( 'Kiala Location Shipment', 'kiala-shipping-for-woocommerce' ); // 
					//$this->label 				= 'Dit is gewoon een test';
					
					
					/*$new_title = get_option('kiala_shipping_title');
					if( !empty($new_title) ){
						$this->title = $new_title;
					} else {
						$this->title = __('Kiala');
					}*/
					
					
					//echo '<hr>'.print_r($test);
					
					$this->init();
					
					$this->enabled            	= $this->settings['enabled']; // This can be added as an setting but for this example its forced enabled
					$this->dspid				= $this->settings['dspid'];
					$this->free_shipping		= $this->settings['free_shipping'];
					$this->inline				= $this->settings['inline'];
					$this->showmap				= $this->settings['showmap'];
					$this->shipping_title		= $this->settings['shipping_title'];
					
					$this->fs_be				= @$this->settings['fs_be'];
					$this->fs_nl				= @$this->settings['fs_nl'];
					$this->fs_fr				= @$this->settings['fs_fr'];
					$this->fs_lu				= @$this->settings['fs_lu'];
					$this->fs_es				= @$this->settings['fs_es'];
				}
		
				/**
				 * Init your settings
				 *
				 * @access public
				 * @return void
				 */
				function init() {
					// Load the settings API
					$this->init_form_fields(); // This is part of the settings API. Override the method to add your own settings
					$this->init_settings(); // This is part of the settings API. Loads settings you previously init.
					update_option('kiala_dspid', $this->settings['dspid']);
					update_option('kiala_free_shipping', $this->settings['free_shipping']);
					update_option('kiala_shipping_title', @$this->settings['shipping_title']);
					update_option('kiala_fs_be', @$this->settings['fs_be']);
					update_option('kiala_fs_nl', @$this->settings['fs_nl']);
					update_option('kiala_fs_lu', @$this->settings['fs_lu']);
					update_option('kiala_fs_es', @$this->settings['fs_es']);
					update_option('kiala_fs_fr', @$this->settings['fs_fr']);
					update_option('kiala_inline', $this->settings['inline']);
					update_option('kiala_showmap', $this->settings['showmap']);
						
					// Save settings in admin if you have any defined
					add_action( 'woocommerce_update_options_shipping_' . $this->id, array( $this, 'process_admin_options' ) );
					
				}
				
				/**
				* Custom settings Kiala
				*/
				function init_form_fields(){
				
					$this->form_fields = array(
					'enabled' => array(
						'title' => __('Enable', 'kiala-shipping-for-woocommerce'),
						'type' => 'checkbox',
						'default' => true,
						'label' => __('Enable Kiala Shipping', 'kiala-shipping-for-woocommerce')
					),
					/*'returnUrl' => array(
						'title' => __('Return URL', 'Kiala Shipping'),
						'type' => 'text',
						'description' => __('')
					),*/
					'dspid' => array(
						  'id' => 'kiala_dspid',
				          'title' => __( 'Your Kiala DSPID', 'kiala-shipping-for-woocommerce' ),
				          'type' => 'text',
				          'description' => __( 'This is your personal Kiala account number (DSPID).', 'kiala-shipping-for-woocommerce' ),
				          'default' => __( 'DEMO_DSP', 'kiala-shipping-for-woocommerce' )
			          ),

					'free_shipping' => array(
						  'id' => 'free_shipping',
				          'title' => __( 'Free shipping?', 'kiala-shipping-for-woocommerce' ),
				          'label' => __('Enable Free shipping', 'kiala-shipping-for-woocommerce'),
				          'type' => 'checkbox',
				          'description' => __( 'Makes the Kiala shipping free from a certain amount.', 'kiala-shipping-for-woocommerce' ),
				          'default' => false
			          ),
			          
			          'inline' => array(
			          
			          		'id' => 'kiala_inline',
					  		'type' => 'checkbox',
			          		'title' => __('Inline layout?', 'kiala-shipping-for-woocommerce'),
			          		'default' => false,
			          		'label' => __('Enable Inline Layout', 'kiala-shipping-for-woocommerce'),
			          		'description' => __('Show the locator map on the side (Storefront theme)', 'kiala-shipping-for-woocommerce')
			          ),
			          'showmap' => array(
			          
			          		'id' => 'kiala_showmap',
					  		'type' => 'checkbox',
			          		'title' => __('Show Google Map?', 'kiala-shipping-for-woocommerce'),
			          		'default' => true,
			          		'label' => __('Enable Google Map', 'kiala-shipping-for-woocommerce'),
			          		'description' => __('Enables Google Map on the Store Locator', 'kiala-shipping-for-woocommerce')
			          ),
			          'shipping_title' => array(
			          		'id' => 'kiala_shipping_title',
			          		'type' => 'text',
			          		'placeholder' => 'Kiala',
			          		'title' => __('Shipping Method Title', 'kiala-shipping-for-woocommerce'),
			          		'description' => __('This will replace the standard "Kiala" title when selecting a Shipping Method','kiala-shipping-for-woocommerce'),
			          ),
			          /*,
					  'description' => array(
				          'title' => __( 'Description', 'woocommerce' ),
				          'type' => 'textarea',
				          'description' => __( 'This controls the description which the user sees during checkout.', 'woocommerce' ),
				          'default' => __("Pay via PayPal; you can pay with your credit card if you don't have a PayPal account", 'woocommerce')
				       )*/
				       
				       
           			);
           			
           			if( 'yes' == get_option('kiala_free_shipping') ){
	           
			   			$this->form_fields = array_merge($this->form_fields, array(
			   			
			   				'fs_be' => array(
							  'id' => 'fs_be',
					          'title' => __( 'Belgium:', 'kiala-shipping-for-woocommerce' ),
					          'type' => 'text',
					          'description' => __( 'Enter the minimum order amount to qualify for free shipping (incl. VAT)', 'kiala-shipping-for-woocommerce' )
				          ),
				          
				          'fs_nl' => array(
							  'id' => 'fs_nl',
					          'title' => __( 'Netherlands:', 'kiala-shipping-for-woocommerce' ),
					          'type' => 'text',
					          'description' => __( 'Enter the minimum order amount to qualify for free shipping (incl. VAT)', 'kiala-shipping-for-woocommerce' )
				          ),
				          
				          'fs_lu' => array(
							  'id' => 'fs_lu',
					          'title' => __( 'Luxemburg:', 'kiala-shipping-for-woocommerce' ),
					          'type' => 'text',
					          'description' => __( 'Enter the minimum order amount to qualify for free shipping (incl. VAT)', 'kiala-shipping-for-woocommerce' )
				          ),
				          
				          'fs_es' => array(
							  'id' => 'fs_es',
					          'title' => __( 'Spain:', 'kiala-shipping-for-woocommerce' ),
					          'type' => 'text',
					          'description' => __( 'Enter the minimum order amount to qualify for free shipping (incl. VAT)', 'kiala-shipping-for-woocommerce' )
				          ),
				          
				          'fs_fr' => array(
							  'id' => 'fs_fr',
					          'title' => __( 'France:', 'kiala-shipping-for-woocommerce' ),
					          'type' => 'text',
					          'description' => __( 'Enter the minimum order amount to qualify for free shipping (incl. VAT)', 'kiala-shipping-for-woocommerce' )
				          )
			   			
			   			));
	           			
           			}
					
				}
				
				public function calc_cost_price($country,$total_cost){
					global $woocommerce;
					
					// Kiala costs
					include 'kiala-costs.php';
										
					/*echo get_option('kiala_fs_'.$country);
					echo floatval(get_option('kiala_fs_'.$country));
					echo $country;
					echo $total_cost;
					echo $kiala_costs[$woocommerce->countries->get_base_country()][strtoupper($country)];*/
					
					if( 'yes' == get_option('kiala_free_shipping') ){
						if( $total_cost >= floatval(get_option('kiala_fs_'.$country)) ){
							return 0;
						} else {
							return $kiala_costs[$woocommerce->countries->get_base_country()][strtoupper($country)];
						}
					}
					
					return $kiala_costs[$woocommerce->countries->get_base_country()][strtoupper($country)];
				}
				
				//$cost = ( 'yes' == get_option('kiala_free_shipping') ) ? ( $total_cost >= floatval(get_option('kiala_fs_'.$country)) ) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()][$country] : $kiala_costs[$woocommerce->countries->get_base_country()][$country];
		
				/**
				 * calculate_shipping function.
				 *
				 * @access public
				 * @param mixed $package
				 * @return void
				 */
				public function calculate_shipping( $package ) {
					global $woocommerce;

					error_log(print_r($package,true));
				
					$total_weight = 0;
					$total_cost = 0;
					$country = $package['destination']['country'];

					if(WP_DEBUG){
						error_log($country);
						error_log(print_r($package, true));
						error_log('Cost:'.$total_cost);
					}
					
					foreach($package['contents'] as $item){
						$product = $item['data'];
						$weight = $product->get_weight();
						$total_cost += $item['line_total'] + $item['line_tax'];
						$total_weight += $weight;
					}

					if(WP_DEBUG){
						error_log('Gewicht van winkelmand: '.$total_weight);
					}
					
					// Kiala max weight 15kg
					if($total_weight <= 15){
					
						switch($country){
							
							case 'LU': // Luxembourg

								//$cost = ($total_cost >= floatval(get_option('kiala_free_shipping'))) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()]['LU'];
								$cost = $this->calc_cost_price('lu', $total_cost);
								
								echo $cost;

								$rate = array(
									'id'    => 'kiala',
									'label' => 'Kiala',
									'cost'  => $cost,
									'taxes' => '',
									'calc_tax' => 'per_order'
								);
							
								$this->add_rate($rate);
							break;
							case 'BE': // Belgium

								//$cost = ($total_cost >= floatval(get_option('kiala_free_shipping'))) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()]['BE'];
								$cost = $this->calc_cost_price('be', $total_cost);

								$rate = array(
									'id'    => 'kiala',
									'label' => 'Kiala',
									'cost'  => $cost,
									'taxes' => '',
									'calc_tax' => 'per_order'
								);
							
								$this->add_rate($rate);
							break;
							case 'FR': // France

								//$cost = ($total_cost >= floatval(get_option('kiala_free_shipping'))) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()]['FR'];
								$cost = $this->calc_cost_price('fr', $total_cost);

								$rate = array(
									'id'    => 'kiala',
									'label' => 'Kiala',
									'cost'  => $cost,
									'taxes' => '',
									'calc_tax' => 'per_order'
								);
							
								$this->add_rate($rate);
							break;
							case 'NL': // Netherlands

								//$cost = ($total_cost >= floatval(get_option('kiala_free_shipping'))) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()]['NL'];
								$cost = $this->calc_cost_price('nl', $total_cost);

								$rate = array(
									'id'    => 'kiala',
									'label' => 'Kiala',
									'cost'  => $cost,
									'taxes' => '',
									'calc_tax' => 'per_order'
								);
							
								$this->add_rate($rate);
							break;
							case 'ES': // Spain

								//$cost = ($total_cost >= floatval(get_option('kiala_free_shipping'))) ? 0 : $kiala_costs[$woocommerce->countries->get_base_country()]['ES'];
								$cost = $this->calc_cost_price('es', $total_cost);

								$rate = array(
									'id'    => 'kiala',
									'label' => 'Kiala',
									'cost'  => $cost,
									'taxes' => '',
									'calc_tax' => 'per_order'
								);
							
								$this->add_rate($rate);
							break;
						}
					}
				}
			}
		}	
	}
	
	add_action( 'woocommerce_shipping_init', 'kiala_shipping_init' );

	//woocommerce_review_order_after_shipping
	//add_action('woocommerce_update_order_review_fragments', 'add_kiala_iframe'); // WC 2.3 update (Refresh with AJAX)
	//add_action('woocommerce_order_update_shipping', 'add_kiala_frame');
	//add_action('woocommerce_checkout_update_order_review', 'add_kiala_frame');

	add_action('woocommerce_review_order_after_order_total', 'add_kiala_iframe');
	add_action('woocommerce_review_order_after_order_total', 'recalc_shipping');

	function recalc_shipping(){
		global $woocommerce;

		$c = new WC_Cart();

		$c->calculate_shipping();

		error_log('done');
	}

	//add_action('woocommerce_review_order_before_payment', 'add_kiala_iframe');
	function add_kiala_iframe(){
		global $woocommerce;

		//echo '<div class="testframe">hallo</div>';

		$shipping_method = $woocommerce->session->get('chosen_shipping_methods');
		
		//print_r($shipping_method);
		
		if( $shipping_method[0] != $woocommerce->session->get('ship_method') || !$woocommerce->session->__isset('ship_method'))
			$woocommerce->session->set('ship_method', $shipping_method[0]);
			
		//echo $woocommerce->session->get('ship_method');
		
		//if( $woocommerce->session->get('ship_method') == 'kiala' ){
		?>
		<script>
			jQuery(document).ready(function(){
				setTimeout(function(){
					jQuery('input[name="shipping_method[0]"][value="<?=$woocommerce->session->get('ship_method')?>"]').prop('checked', true);
				}, 250);
			});
		</script>
		<?php
		//}

		$kiala_parameters = array(	'shortkpid',
										'kpname',
										'street',
										'zip',
										'city',
										'image',
										'openinghours');
										
		
		
		if(isset($_GET['shortkpid'])){ // Return URL from KIALA
										
			foreach($kiala_parameters as $id => $param){
				$woocommerce->session->set('kiala_'.$param, $_GET[$param]);
			}
			
			if( $woocommerce->session->get('ship_method') == 'kiala' ){
			?>
			<script>
				jQuery(document).ready(function(){
					setTimeout(function(){
						jQuery('input[name="shipping_method[0]"][value="kiala"]').prop('checked', true);
					}, 250);
				});
				jQuery(window).load(function(){
					jQuery(document).scrollTop( jQuery("#kiala").offset().top );
				});
			</script>
			<?php
			}
		}
		
		
		if(isset($_GET['kiala_reset'])){
			if( $woocommerce->session->get('ship_method') == 'kiala' ){
			?>
			<script>
				jQuery(document).ready(function(){
					setTimeout(function(){
						jQuery('input[name="shipping_method[0]"][value="kiala"]').prop('checked', true);
					}, 250);
				});
				jQuery(window).load(function(){
					jQuery(document).scrollTop( jQuery("#kiala").offset().top );
				});
			</script>
			<?php
			}
		}
		
		if(isset($_GET['kiala_reset']) || !@$shipping_method[0] == 'kiala'){
			$woocommerce->session->__unset('kiala_shortkpid');
			foreach($kiala_parameters as $id => $param){
				$woocommerce->session->__unset('kiala_'.$param);
			}	
		}
		
		/*echo '<pre>';
		//print_r(WC()->checkout);
		//print_r($woocommerce->customer);
		//print_r($woocommerce);
		//print_r($woocommerce->order);
		echo '</pre>';*/
		//print_r($shipping_method);
			
		if(@$shipping_method[0] == 'kiala' && !$woocommerce->session->__isset('kiala_shortkpid')){
		/*global $checkout;
		foreach ( $checkout->checkout_fields['billing'] as $key => $field ){
			echo $checkout->get_value($key);
		}*/
		
		$addToUrl = '';


		echo '<tr><td colspan="2">';
		
		?>
		
		<div class="kiala_point">
		<h3 id="kiala"><?=__('Select your Kiala Point:', 'kiala-shipping-for-woocommerce')?></h3>
		
		<?php
		
			$postcode = $woocommerce->customer->get_postcode();
			
			if( ! empty( $postcode ) ) {
			
		?>
		<?=$woocommerce->session->get('kiala_shortkpid')?>
		
		<?php
			
			if( get_option('kiala_inline') == "yes" ){
				
				$charToAdd = (substr($woocommerce->cart->get_checkout_url(),-1) == '/') ? '?' : '&';
				
				?>
				<iframe class="kiala_framed" frameborder="0" width="100%" height="500" src="http://locateandselect.kiala.com/search?dspid=<?=get_option('kiala_dspid')?>&country=<?=$woocommerce->customer->get_shipping_country()?>&language=&preparationdelay=&street=<?=$woocommerce->customer->get_shipping_address()?>&zip=<?=$woocommerce->customer->get_shipping_postcode();?>&city=<?=$woocommerce->customer->get_shipping_city()?>&bckUrl=<?=urlencode($woocommerce->cart->get_checkout_url().$charToAdd)?>&target=_parent&select-text=&header=&thumbnails=off&map=<?=(get_option('kiala_showmap') == 'yes') ? 'on' : 'off'?>&css=<?php echo plugins_url('css/kiala-basic.css', __FILE__);?>&map-controls=&align=&pl=map&list=&sort-method=&max-result=&header=off&zipfilter="></iframe>
				<?php
				
			} else {
			
		?>
		
		<a class="button alt" href="#" id="kiala_select_button"><?php echo __('Select Kiala Point', 'kiala-shipping-for-woocommerce')?></a>

		<div class="kiala_lightbox">
			<div class="kiala_frame">
			</div>
		</div>

		</div>

		<div class="kiala_point_chosen">

			<a class="button alt" href="#" id="kiala_select_another"><?php echo __('Select another point','kiala-shipping-for-woocommerce'); ?></a>

			<div class="kiala_point_chosen_frame">
			</div>
		</div>

		<?php
			
			}
			
		?>
		
		
		<?php
			
			} else {
				
		?>
			<?=$woocommerce->session->get('kiala_kpid');?>
			<?=__('Please enter your address', 'kiala-shipping-for-woocommerce');?>
		<?php
				
			}
			
		?>

		<!--<iframe class="kiala_frame" width="100%" height="500" src="http://locateandselect.kiala.com/search?dspid=<?=get_option('kiala_dspid')?>&country=<?=$woocommerce->customer->get_shipping_country()?>&language=&preparationdelay=&street=<?=$woocommerce->customer->get_shipping_address()?>&zip=<?=$woocommerce->customer->get_shipping_postcode();?>&city=<?=$woocommerce->customer->get_shipping_city()?>&bckUrl=<?=urlencode($woocommerce->cart->get_checkout_url().'&')?>&target=_parent&select-text=&header=&thumbnails=&map=&css=&map-controls=&align=&pl=map&list=&sort-method=&max-result=&header=off&zipfilter="></iframe>
		</div>-->
		
		<?php

		echo '</td></tr>';

		} elseif(@$shipping_method[0] == 'kiala' && $woocommerce->session->__isset('kiala_shortkpid')) {

			echo '<tr><td colspan="2">';

			// Reset url
			$reset_url = (substr($woocommerce->cart->get_checkout_url(),-1) == '/') ? '?kiala_reset' : '&kiala_reset';
		?>

		
		<div class="kiala_point">
		<h3 id="kiala"><?=__('Your chosen Kiala Point:', 'kiala-shipping-for-woocommerce')?></h3> <a class="kiala_reset_button" href="<?=$woocommerce->cart->get_checkout_url()?><?=$reset_url?>"><?=__('Choose another Kiala Point', 'kiala-shipping-for-woocommerce')?></a>
		
		<input type="hidden" name="kiala_shortkpid" value="<?=$woocommerce->session->get('kiala_shortkpid')?>">
		
		<!-- Send KIALA info -->
		<input type="hidden" name="kiala_image" value="<?=urldecode($woocommerce->session->get('kiala_image'))?>">
		<input type="hidden" name="kiala_street" value="<?=$woocommerce->session->get('kiala_street')?>">
		<input type="hidden" name="kiala_kpname" value="<?=$woocommerce->session->get('kiala_kpname')?>">
		<input type="hidden" name="kiala_zip" value="<?=$woocommerce->session->get('kiala_zip')?>">
		<input type="hidden" name="kiala_city" value="<?=$woocommerce->session->get('kiala_city')?>">
		<input type="hidden" name="kiala_openinghours" value="<?=$woocommerce->session->get('kiala_openinghours')?>">
		
		<?php
		/*$kiala_costs = array( 'BE' => array('BE' => 3.72, 'LU' => 3.72, 'NL' => 6.20, 'FR' => 8.27, 'ES' => 11.57),
										  'NL' => array('BE' => 6.20, 'LU' => 6.20, 'NL' => 3.26, 'FR' => 8.27, 'ES' => 11.57)
										);
		print_r($kiala_costs[$woocommerce->countries->get_base_country()]);
		echo $woocommerce->countries->get_base_country();*/
		/*echo $woocommerce->session->get('kiala_shortkpid');
		foreach($kiala_parameters as $id => $param){
				if($param == 'image')
				echo '<img src="http://'.urldecode($woocommerce->session->get('kiala_'.$param)).'">';
				else
				echo $woocommerce->session->get('kiala_'.$param);
		}*/
		
		?>
			
			<iframe frameborder="0" class="kiala_frame_" src="http://locateandselect.kiala.com/locateandselect/details?dspid=<?=get_option('kiala_dspid')?>&country=<?=$woocommerce->customer->get_shipping_country()?>&language=&preparationdelay=&shortID=<?=$woocommerce->session->get('kiala_shortkpid')?>&map=off&css=<?php echo plugins_url('css/kiala-basic.css', __FILE__);?>&list=" width="100%" height="400"></iframe>
			
		</div>
		<?php

		echo '</td></tr>';
	
		}

		?>
		<script>
		jQuery('.kiala_lightbox').on('click', function(){
		jQuery(this).hide();
		});

		jQuery('#kiala_select_button').on('click', function(e){
			e.preventDefault();
			jQuery('.kiala_frame').html('');
			/* Fallback */
			<?php
			$charToAdd = (substr($woocommerce->cart->get_checkout_url(),-1) == '/') ? '?' : '&';
			?>
			jQuery('.kiala_frame').html('<iframe class="kiala_framed" frameborder="0" width="100%" height="500" src="http://locateandselect.kiala.com/search?dspid=<?=get_option('kiala_dspid')?>&country=<?=$woocommerce->customer->get_shipping_country()?>&language=&preparationdelay=&street=<?=$woocommerce->customer->get_shipping_address()?>&zip=<?=$woocommerce->customer->get_shipping_postcode();?>&city=<?=$woocommerce->customer->get_shipping_city()?>&bckUrl=<?=urlencode($woocommerce->cart->get_checkout_url().$charToAdd)?>&target=_parent&select-text=&header=&thumbnails=&map=&css=<?php echo plugins_url('css/kiala-basic.css', __FILE__);?>&map-controls=&align=&pl=map&list=&sort-method=&max-result=&header=off&zipfilter="></iframe>');

			/*
			jQuery('.kiala_frame').html('<iframe class="kiala_framed" width="100%" height="500" src="<?=plugins_url('load-kiala.php',__FILE__)?>?dspid=<?=get_option('kiala_dspid')?>&country=<?=$woocommerce->customer->get_shipping_country()?>&language=&preparationdelay=&street=<?=$woocommerce->customer->get_shipping_address()?>&zip=<?=$woocommerce->customer->get_shipping_postcode();?>&city=<?=$woocommerce->customer->get_shipping_city()?>&bckUrl=<?=urlencode($woocommerce->cart->get_checkout_url().'&')?>&target=_parent&select-text=&header=&thumbnails=&map=&css=<?php echo plugins_url('css/kiala-basic.css', __FILE__);?>&map-controls=&align=&pl=map&list=&sort-method=&max-result=&header=off&zipfilter="></iframe>');
			*/
			jQuery('.kiala_lightbox').show();
		});

		/*jQuery('#kiala_select_another').on('click', function(e){
			e.preventDefault();
			jQuery('.kiala_point_chosen').hide();
			jQuery('input[name="kiala_shortkpid"]').val('');
			jQuery('.kiala_point').show();
		});*/
		</script>
		<?php
	}
	
	add_action( 'woocommerce_checkout_update_order_meta', 'my_custom_checkout_field_update_order_meta' );
	 
	function my_custom_checkout_field_update_order_meta( $order_id ) {
		global $woocommerce; 
		
	    /*if ( $woocommerce->session->__isset('kiala_shortkpid') ) {
	        update_post_meta( $order_id, 'kiala_shortkpid', sanitize_text_field( $woocommerce->session->get('kiala_shortkpid') ) );
	        update_post_meta( $order_id, 'country', sanitize_text_field( $woocommerce->customer->get_shipping_country() ) );
	    }*/

	    if ( ! empty( $_POST['kiala_shortkpid'] ) ) {
	        update_post_meta( $order_id, 'kiala_shortkpid', sanitize_text_field( $_POST['kiala_shortkpid'] ) );
	        update_post_meta( $order_id, 'country', sanitize_text_field( $woocommerce->customer->get_shipping_country() ) );
	        update_post_meta( $order_id, 'kiala_street', sanitize_text_field( $_POST['kiala_street'] ) );
	        update_post_meta( $order_id, 'kiala_kpname', sanitize_text_field( $_POST['kiala_kpname'] ) );
	        update_post_meta( $order_id, 'kiala_image', sanitize_text_field( $_POST['kiala_image'] ) );
	        update_post_meta( $order_id, 'kiala_zip', sanitize_text_field( $_POST['kiala_zip'] ) );
	        update_post_meta( $order_id, 'kiala_city', sanitize_text_field( $_POST['kiala_city'] ) );
	        update_post_meta( $order_id, 'kiala_openinghours', sanitize_text_field( $_POST['kiala_openinghours'] ) );
	    }
	}
	 
	function kiala_chosen_point() {
		global $woocommerce; 
		
		if($_POST['shipping_method'][0] == 'kiala'  && !$_POST['kiala_shortkpid']){
			wc_add_notice( __( 'Please choose a <strong>Kiala point</strong>', 'kiala-shipping-for-woocommerce' ), 'error' );
		}
		
	    /*$shipping_method = $woocommerce->session->get('chosen_shipping_methods');
		if(@$shipping_method[0] == 'kiala' && !$woocommerce->session->__isset('kiala_shortkpid')){
		//if(@$shipping_method[0] == 'kiala' && ( !isset($_POST['kiala_shortkpid']) || empty($_POST['kiala_shortkpid']) ) ) {
	        wc_add_notice( __( 'Please choose a Kiala point' ), 'error' );
	    }*/
	}
	add_action('woocommerce_checkout_process', 'kiala_chosen_point');
	
	function reset_kiala_kpid_when_order_complete(){
		global $woocommerce;
		
		$woocommerce->session->__unset('kiala_shortkpid');
	}
	add_action('woocommerce_payment_complete', 'reset_kiala_kpid_when_order_complete');

	// Register Kiala return url parameters
	/*function add_query_vars_filter( $vars ){
	  $vars[] = 'shortkpid';
	  return $vars;
	}
	add_filter( 'query_vars', 'add_query_vars_filter' );*/
	
	/* ADD META BOX	*/
	/**
	 * Adds a box to the main column on the Post and Page edit screens.
	 */
		
	function myplugin_add_meta_box( ) {
		global $post;
		
		$screens = array('shop_order');
	
		$id = get_post_meta($post->ID, 'kiala_shortkpid', true);
		if(!empty($id)){
			foreach ( $screens as $screen ) {
		
				add_meta_box(
					'kiala_shipping',
					__( 'Kiala Shipping Point', 'kiala-shipping-for-woocommerce' ),
					'myplugin_meta_box_callback',
					$screen,
					'normal',
					'low'
				);
			}
		}
	}
	add_action( 'add_meta_boxes', 'myplugin_add_meta_box' );
			
	/**
	 * Prints the box content.
	 * 
	 * @param WP_Post $post The object for the current post/page.
	 */
	function myplugin_meta_box_callback( $post ) {

		// Add an nonce field so we can check for it later.
		wp_nonce_field( 'myplugin_meta_box', 'myplugin_meta_box_nonce' );
	
		/*
		 * Use get_post_meta() to retrieve an existing value
		 * from the database and use the value for the form.
		 */
		/*$value = get_post_meta( $post->ID, '_my_meta_value_key', true );*/
	    echo '<iframe frameborder="0" src="http://locateandselect.kiala.com/locateandselect/details?dspid='.get_option('kiala_dspid').'&country='.get_post_meta( $post->ID, 'country', true ).'&language=&preparationdelay=&shortID='.get_post_meta( $post->ID, 'kiala_shortkpid', true ).'" width="100%" height="400"></iframe>';
		
	}
	
	
	
	// Register shipping method
	function add_kiala_shipping( $methods ) {
		$methods[] = 'Kiala_shipping'; 
		return $methods;
	}

	function kiala_point_show_order($post){
		
		$order = new WC_order($post->id);
		if( $order->get_shipping_method() == 'kiala' ) {
		
		?>
		
		
		
		<h2><?php echo __('Chosen Kiala Point', 'kiala-shipping-for-woocommerce');?></h2>

		<iframe frameborder="0" src="http://locateandselect.kiala.com/locateandselect/details?dspid=<?=get_option('kiala_dspid');?>&country=<?=get_post_meta( $post->id, 'country', true )?>&language=&preparationdelay=&shortID=<?=get_post_meta( $post->id, 'kiala_shortkpid', true )?>" width="100%" height="400"></iframe>
		<?php
		
		}
	}
	add_action('woocommerce_order_details_after_order_table', 'kiala_point_show_order');

	// Select Kiala shop via AJAX/non-AJAX


		
	
	// Force country
	//add_filter( 'woocommerce_formatted_address_force_country_display', '__return_true' );
	
	add_filter( 'woocommerce_shipping_methods', 'add_kiala_shipping' );
	
	// Change Kiala shipping method title
	add_filter('woocommerce_cart_shipping_method_full_label', 'change_kiala_shipping_method_title', 10, 2);
	
	function change_kiala_shipping_method_title( $label, $method ){
		
		$new_title = get_option('kiala_shipping_title');
		if( !empty($new_title) ){
			$label = str_replace('Kiala', $new_title, $label);
		}
		
		return $label;
	}
	
	// Add Kiala to the mail template
	function add_kiala_information_to_email( $order, $is_admin ){
		
		$kiala_id = get_post_meta($order->id, 'kiala_shortkpid', true);
		$order = new WC_order($order->id);
		
		if( !empty($kiala_id) && $order->get_shipping_method() == 'kiala' ){ 
		
			
	
			echo '<br>';
			
			echo '<h2>'.__('Your selected Kiala point.', 'kiala-shipping-for-woocommerce').'</h2>';
			
			echo '<img src="http://'.get_post_meta($order->id, 'kiala_image', true).'" style="max-width: 175px;">'; echo '<br/>';
			echo get_post_meta($order->id, 'kiala_kpname', true); echo '<br/>';
			echo get_post_meta($order->id, 'kiala_street', true); echo '<br/>';
			echo get_post_meta($order->id, 'kiala_zip', true);
			echo ' '.get_post_meta($order->id, 'kiala_city', true); echo '<br/>';
			echo get_post_meta($order->id, 'kiala_country', true); echo '<br/>';
		
		}
	}
	add_action('woocommerce_email_after_order_table', 'add_kiala_information_to_email', 10, 2);
	
	function remove_shipping_address_in_email( $shipping_methods ){
		$shipping_methods[] = 'kiala';
		return $shipping_methods;
	}           
	add_filter('woocommerce_order_hide_shipping_address', 'remove_shipping_address_in_email'); 

}
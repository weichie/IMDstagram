<?php

$buildURL = 'http://locateandselect.kiala.com/search?dspid='						. $_GET['kiala_dspid'] .
															'&country='				. $_GET['country'] .
															'&language='			. $_GET['language'] .
															'&preparationdelay='	.
															'&street=' 	  			. str_replace(' ', '%20', urlencode($_GET['street'])) .
															'&zip='        			. urlencode($_GET['zip']) .
															'&city='				. urlencode($_GET['city']) .
															'&bckUrl='				. urlencode($_GET['bckUrl']) .
															'&target='				. urlencode($_GET['target']) .
															'&select-text='			.
															'&header='				.
															'&thumbnails='			.
															'&map='					.
															'&css='					. urlencode($_GET['css']) .
															'&map-controls='		.
															'&align='				.
															'&pl=map'				.
															'&list='				.
															'&sort-method='			.
															'&max-result='			.
															'&header=off'			.
															'&zipfilter=';
//echo $buildURL;

$html = file_get_contents($buildURL);

$html = str_replace('<head>', '<head><base href="http://locateandselect.kiala.com">', $html);
$html = str_replace('<meta name="viewport" content="width=480; user-scalable=1;" />', '<meta name="viewport" content="width=device-width, initial-scale=1">', $html);

$html = str_replace('</body>', "
<script>
	$('.kp').each(function(){
		var link = $(this).find('.select a').attr('href');
		$(this).find('a').attr('href', '#');
		$(this).find('.select a').attr('onclick', 'event.preventDefault();parent.selectKiala(\"".$_GET['kiala_dspid']."\",\"".$_GET['country']."\",\"'+link+'\",\"".$_GET['css']."\")');
	});
</script>

</body>", $html);

echo $html;

?>
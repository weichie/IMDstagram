<?php

$kiala_costs = array( 
	'BE' => array(
		'BE' => 3.72,
		'LU' => 3.72,
		'NL' => 6.20,
		'FR' => 8.27,
		'ES' => 11.57),
	'NL' => array(
		'BE' => 6.20,
		'LU' => 6.20,
		'NL' => 3.26,
		'FR' => 8.27,
		'ES' => 11.57)
);

?>
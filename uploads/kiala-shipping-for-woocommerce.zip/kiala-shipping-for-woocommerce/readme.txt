=== Parcel, Kiala for WooCommerce by Yame ===
Contributors: Yame
Tags: parcel, kiala, woocommerce
Requires at least: 4.0
Tested up to: 4.2.3
Stable tag: 4.2.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The easiest plugin to connect Kiala parcel delivery service to a WooCommerce store.